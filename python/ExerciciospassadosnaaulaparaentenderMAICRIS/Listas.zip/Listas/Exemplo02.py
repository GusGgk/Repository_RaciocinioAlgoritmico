nums = []
while True:
    num = int(input("Digite um número (0 sair): "))
    if num == 0:
        break
    nums.append(num)
for num in nums:
    print(num)
for i in range(len(nums)):
    print(nums[i])
print(nums)
print(*nums)
