"""
Criando Listas em Python
"""
nums = []
for i in range(5):
    num = int(input(f"Digite o {i+1}º número: "))
    nums.append(num)
for num in nums:
    print(num)
soma = sum(nums)
print(soma)
media = sum(nums)/len(nums)
print(media)
