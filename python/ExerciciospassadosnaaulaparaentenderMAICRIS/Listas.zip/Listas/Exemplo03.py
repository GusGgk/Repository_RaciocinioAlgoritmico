nome = "Maicris"
for letra in nome:
    if letra in "aeiou":
        print(f"Vogal encontrada: {letra}")
